# ملک‌یار — MelkYar Android Commercial Starter v1.0

این پروژه یک Android project واقعی برای باز شدن در Android Studio است، با رابط فارسی RTL، محاسبات اولیه، لینک‌های رسمی نقشه/تهران من، انتخاب عکس نمای خیابان و ساختار قابل توسعه.

## Build روی کامپیوتر
1. Android Studio جدید را نصب کنید.
2. این پوشه را با Open باز کنید.
3. Gradle Sync را انجام دهید.
4. Run برای تست روی گوشی.
5. Build > Generate App Bundles or APKs > Generate APK برای APK آزمایشی.
6. برای Google Play نسخه Release و AAB بسازید.

## نکته مهم
این نسخه «هسته تجاری/قابل توسعه» است، اما هنوز اتصال خودکار به API شهرداری و موتور نهایی ضوابط رسمی داخل آن ادعا نشده است. محاسبات نمونه باید با داده رسمی تهران و موتور Rule Engine تأییدشده جایگزین شوند.

منابع:
https://map.tehran.ir/
https://mytehran.ir/auth/login?returnUrl=%2Fhome
